#include <iostream>
using namespace std;
class A
{
    static int x; int y;
    public: A(int i) {x=i; y=-i;}
        static int put_x(int i=x){x=i; y=-i; return x; } };

int A::x=5;
int main()
{
    A *a(7);
    cout<<A::put_x();
    return 0;
}
