﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ODATAWebAPI2023.Models
{
    public class DateOdata
    {
        public int Id { get; set; }
        public string Datastr { get; set; }
    }
}