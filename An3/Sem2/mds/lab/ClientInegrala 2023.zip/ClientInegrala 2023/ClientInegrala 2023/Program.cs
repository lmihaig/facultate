﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace ClientInegrala_2023
{
    internal class Program
    {
        private static object integr;

        public static object Clientintegrala2023 { get; private set; }

        static void Main(string[] args)
        {
            double x1 = 1;
            double x2 = 3;
            object valint = new ServiceReference1.Service1Client().Simpson(x1,x2);
            string integrx = valint.ToString();
            Console.WriteLine("valoarea integralei este : " + integrx);
            Console.ReadKey();

        }
    }
}
