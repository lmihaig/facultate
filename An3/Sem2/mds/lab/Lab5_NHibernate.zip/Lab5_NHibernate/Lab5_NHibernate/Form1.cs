﻿using Lab5_NHibernate;
using NHibernate;
using NHibernate.Cfg;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab5_NHibernate
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            myUBConfiguration = new Configuration();
            myUBConfiguration.Configure();
            myUBSessionFactory = myUBConfiguration.BuildSessionFactory();
            myUBSession = myUBSessionFactory.OpenSession();
            using (myUBSession.BeginTransaction())
            {
                Balti balta = new Balti
                {
                    TitluBaltaPescuit = "Test Balta",
                    Descriere = "O descriere a baltii",
                    Adresa = "Adresa baltii",
                    Telefon = "0700000111",
                    CodBalta = "EST"
                };
                try
                {
                    myUBSession.Save(balta);
                    myUBSession.Transaction.Commit();
                    MessageBox.Show("Datele au fost salvate cu succes.");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Urmatoarea eroare a fost intampinata -> " +
                    ex.Message.ToString());
                }
            }
        }
    }
}
