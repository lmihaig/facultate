﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab5_NHibernate
{
    public class Balti
    {
        public int ID { get; set; }
        public string TitluBaltaPescuit { get; set; }
        public string Descriere { get; set; }
        public string Adresa { get; set; }
        public string Telefon { get; set; }
        public string CodBalta { get; set; }
    }
}
