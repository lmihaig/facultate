﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab4_MDS_Exemplu4_EntityFramework
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnAfiseazaArticol_Click(object sender, EventArgs e)
        {
            using (MDS_Lab4Entities db = new MDS_Lab4Entities())
            {
                Articole art = db.Articoles.Where((x) => x.CodArticol == "A05").FirstOrDefault();
                MessageBox.Show(art.DescriereArticol);
            }
        }

        private void btnAfiseazaArticolJoin_Click(object sender, EventArgs e)
        {
            using (MDS_Lab4Entities db = new MDS_Lab4Entities())
            {
                var articolProdus = db.Articoles
                            .Join(db.FamilieProduses,
                                  articol => articol.CodArticolFamilie,
                                  famileProduse => famileProduse.CodArticolFamilie,
                                  (articol, famileProduse) => new { Articole = articol, FamilieProduse = famileProduse })
                            .Where((x) => x.Articole.CodArticol == "A05")
                            .FirstOrDefault();

                MessageBox.Show(articolProdus.Articole.DescriereArticol + " - " + articolProdus.FamilieProduse.DescriereFamilie);
            }
        }

        private void btnAfisareProdusForeignKey_Click(object sender, EventArgs e)
        {
            using (MDS_Lab4Entities db = new MDS_Lab4Entities())
            {
                Articole art = db.Articoles.Where((x) => x.CodArticol == "A05").FirstOrDefault();
                MessageBox.Show(art.DescriereArticol + " - " + art.FamilieProduse.DescriereFamilie);
            }
        }
    }
}
