USE [MDS_Lab4]  
GO  
   
SET ANSI_NULLS ON  
GO  
   
SET QUOTED_IDENTIFIER ON  
GO  
   
CREATE TABLE [dbo].[Articole](  
    [IDArticol] [int] IDENTITY(1,1) NOT NULL,  
    [CodArticol] [nvarchar](25) NOT NULL,  
    [DescriereArticol] [nvarchar](50) NOT NULL,  
    [CodArticolFamilie] [nvarchar](6) NOT NULL,  
 CONSTRAINT [PK_Articole] PRIMARY KEY CLUSTERED  
(  
    [IDArticol] ASC  
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]  
) ON [PRIMARY]  
   
GO  
   
ALTER TABLE [dbo].[Articole] ADD  CONSTRAINT [DF_Articole_CodArticol]  DEFAULT ('') FOR [CodArticol]  
GO  
   
ALTER TABLE [dbo].[Articole] ADD  CONSTRAINT [DF_Articole_DescriereArticol]  DEFAULT ('') FOR [DescriereArticol]  
GO  
   
ALTER TABLE [dbo].[Articole] ADD  CONSTRAINT [DF_Articole_CodArticolFamilie]  DEFAULT ('') FOR [CodArticolFamilie]  
GO  
   
CREATE TABLE [dbo].[Familie](  
    [CodArticolFamilie] [nvarchar](6) NOT NULL,  
    [DescriereFamilie] [nvarchar](50) NOT NULL,  
 CONSTRAINT [PK_Familie] PRIMARY KEY CLUSTERED  
(  
    [CodArticolFamilie] ASC  
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]  
) ON [PRIMARY]  
   
GO