USE [MDS_Lab4]  
       
INSERT INTO Articole(CodArticol, DescriereArticol, CodArticolFamilie) VALUES ('A01', 'Articol Test 1' , 'F01')  
INSERT INTO Articole(CodArticol, DescriereArticol, CodArticolFamilie) VALUES ('A02', 'Alt articol test', 'F01')  
INSERT INTO Articole(CodArticol, DescriereArticol, CodArticolFamilie) VALUES ('A03', 'A. 03', 'F02')  
INSERT INTO Articole(CodArticol, DescriereArticol, CodArticolFamilie) VALUES ('A04', 'A. 04', 'F02')  
INSERT INTO Articole(CodArticol, DescriereArticol, CodArticolFamilie) VALUES ('A05', 'A. 05', 'F02')  
INSERT INTO Articole(CodArticol, DescriereArticol, CodArticolFamilie) VALUES ('A06', 'A. 06', 'F02')  
INSERT INTO Articole(CodArticol, DescriereArticol, CodArticolFamilie) VALUES ('A07', 'A. 07', 'F03')  
INSERT INTO Articole(CodArticol, DescriereArticol, CodArticolFamilie) VALUES ('A08', 'A. 08', 'F04')  
       
INSERT INTO Familie(CodArticolFamilie, DescriereFamilie) VALUES ('F01', 'PRODUSE GRADINARIT')  
INSERT INTO Familie(CodArticolFamilie, DescriereFamilie) VALUES ('F02', 'PRODUSE CURATENIE')  
INSERT INTO Familie(CodArticolFamilie, DescriereFamilie) VALUES ('F03', 'PRODUSE ELECTRICE')  
INSERT INTO Familie(CodArticolFamilie, DescriereFamilie) VALUES ('F04', 'PRODUSE EXPORT')  
