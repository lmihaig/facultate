﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StrategyPattern_RealWorldExample_ArithmeticOperations
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Context context = new Context(new Adunare());
            Console.WriteLine("23 + 2 = " + context.realizeazaStrategia(23, 2));

            context = new Context(new Scadere());
            Console.WriteLine("23 - 2 = " + context.realizeazaStrategia(23, 2));

            context = new Context(new Inmultire());
            Console.WriteLine("23 * 2 = " + context.realizeazaStrategia(23, 2));

            Console.ReadKey ();
        }
    }
}
