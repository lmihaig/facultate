﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StrategyPattern_RealWorldExample_ArithmeticOperations
{
    public class Context
    {
        private Strategie strategie;

        public Context(Strategie strategie)
        {
            this.strategie = strategie;
        }

        public int realizeazaStrategia(int valoare1, int valoare2)
        {
            return strategie.operatie(valoare1, valoare2);
        }
    }
}
