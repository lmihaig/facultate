﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StrategyPattern_RealWorldExample_ArithmeticOperations
{
    public class Adunare : Strategie
    {
        public override int operatie(int valoare1, int valoare2)
        {
            return valoare1 + valoare2;
        }
    }
}
