﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab2_MDS_Exemplu2_ORM_LinqToSQL
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            CustomizeListView(lvDatePersoane);
        }

        public void CustomizeListView(ListView lv)
        {
            lv.View = View.Details;
            lv.FullRowSelect = true;

            lv.Columns.Add("ID");
            lv.Columns.Add("Nume");
            lv.Columns.Add("Prenume");
            lv.Columns.Add("Telefon");
            lv.Columns.Add("E-mail");
            lv.Columns.Add("Varsta");

            lv.Show();
        }

      

        private void btnIesire_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //pozitionam fereastra pe centrul ecranului
            this.CenterToScreen();

            // incarcam datele din baza de date, din tabelul DatePersonale
            LoadDatePersoane(lvDatePersoane);
            lvDatePersoane.AutoResizeColumns(ColumnHeaderAutoResizeStyle.HeaderSize);
        }

        public void LoadDatePersoane(ListView lv)
        {
            DataClasses1DataContext dc = new DataClasses1DataContext();
            
            //echivalentul pentru instructiunea select din limbajul SQL
            var datePersoane = from x in dc.DatePersonales
                               select x;

            foreach(var dp in datePersoane)
            {
                ListViewItem lvi = new ListViewItem(dp.ID.ToString());
                lvi.SubItems.Add(dp.Nume.ToString());
                lvi.SubItems.Add(dp.Prenume.ToString());
                lvi.SubItems.Add(dp.Telefon.ToString());
                lvi.SubItems.Add(dp.Email.ToString());
                lvi.SubItems.Add(dp.Varsta.ToString());

                lv.Items.Add(lvi);
            }
            lvDatePersoane.AutoResizeColumns(ColumnHeaderAutoResizeStyle.HeaderSize);
        }

        private void btnAdauga_Click(object sender, EventArgs e)
        {
            //echivalentul pentru insert

            DataClasses1DataContext dc = new DataClasses1DataContext();

            DatePersonale dp = new DatePersonale();
            dp.Nume = txtNume.Text.ToString();
            dp.Prenume = txtPrenume.Text.ToString();
            dp.Telefon = txtTelefon.Text.ToString();
            dp.Email = txtEmail.Text.ToString();
            dp.Varsta = Convert.ToInt32(txtVarsta.Text);

            try
            {
                dc.DatePersonales.InsertOnSubmit(dp);
                dc.SubmitChanges();
                MessageBox.Show("Datele au fost adaugate cu succes");
            }
            catch(Exception ex)
            {
                MessageBox.Show("Inregistrarea a fost adaugata cu succes");
            }           

            //reincarcam baza de date astfel incat noua inregistrare sa fie reflectata
            lvDatePersoane.Items.Clear();
            LoadDatePersoane(lvDatePersoane);

            //facem clear la controale astfel incat sa le pregatim pentru o noua inregistrare
            txtNume.Text = "";
            txtPrenume.Text = "";
            txtTelefon.Text = "";
            txtEmail.Text = "";
            txtVarsta.Text = "";
        }

        private void lvDatePersoane_SelectedIndexChanged(object sender, EventArgs e)
        {            
            ListView.SelectedListViewItemCollection dateDesprePersoane = this.lvDatePersoane.SelectedItems;
            foreach (ListViewItem item in dateDesprePersoane)
            {
                txtIDPersoana.Text = item.SubItems[0].Text;
                txtNumeExistent.Text = item.SubItems[1].Text;
                txtPrenumeExistent.Text = item.SubItems[2].Text;
                txtTelefonExistent.Text = item.SubItems[3].Text;
                txtEmailExistent.Text = item.SubItems[4].Text;
                txtVarstaExistent.Text = item.SubItems[5].Text;
            }
        }

        private void btnModifica_Click(object sender, EventArgs e)
        {
            //operatia de update
            DataClasses1DataContext dc = new DataClasses1DataContext();

            DatePersonale dp = dc.DatePersonales.Single(id => id.ID == Convert.ToInt32(txtIDPersoana.Text));
            dp.Nume = txtNumeExistent.Text;
            dp.Prenume = txtPrenumeExistent.Text;
            dp.Telefon = txtTelefonExistent.Text;
            dp.Email = txtEmailExistent.Text;
            dp.Varsta = Convert.ToInt32(txtVarstaExistent.Text);

            try
            {
                dc.SubmitChanges();
                MessageBox.Show("Actualizarea a fost realizata cu succes");
                //reincarcam baza de date astfel incat noua inregistrare sa fie reflectata
                lvDatePersoane.Items.Clear();
                LoadDatePersoane(lvDatePersoane);
            }
            catch(Exception ex)
            {
                MessageBox.Show("Inregistrarea cu ID-ul: " + txtIDPersoana.Text.ToString() + " nu a putut fi actualizata corespunzator. Mesajul errorii este: " + ex.Message.ToString());
            }   
        }

        private void btnSterge_Click(object sender, EventArgs e)
        {
            DataClasses1DataContext dc = new DataClasses1DataContext();
            if (txtIDPersoana.Text == "")
            {
                MessageBox.Show("Selectati o persoana pentru stergere");
            }
            else
            {
                int idPers = Convert.ToInt32(txtIDPersoana.Text);

                DatePersonale dp = dc.DatePersonales.Single(id => id.ID == idPers);
                dc.DatePersonales.DeleteOnSubmit(dp);

                try
                {
                    dc.SubmitChanges();
                    MessageBox.Show("Stergerea inregistrarii a fost efectuata cu succes");
                    lvDatePersoane.Items.Clear();
                    LoadDatePersoane(lvDatePersoane);
                }
                catch(Exception ex)
                {
                    MessageBox.Show("Inregistrarea cu ID-ul: " + txtIDPersoana.Text.ToString() + " nu a putut fi stearsa corespunzator. Mesajul errorii este: " + ex.Message.ToString());
                }
            }
        }
    }
}
