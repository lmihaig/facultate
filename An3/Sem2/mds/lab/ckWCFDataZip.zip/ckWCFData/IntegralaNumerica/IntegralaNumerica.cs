using System;
using IntegralaNumerica.ServiceReference1;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;

namespace IntegralaNumerica
{
    class IntegralaNumerica
    {
        static void Main(string[] args)
        {
            // The code provided will print ‘Hello World’ to the console.
            // Press Ctrl+F5 (or go to Debug > Start Without Debugging) to run your app.
            Console.WriteLine("Calculul Integralei Numerice cu Metoda Trapezelor");
            Console.Write("Indicati limita inferioara : ");
            string a = Console.ReadLine();
            int a1 = Convert.ToInt16(a);
            Console.Write("Indicati limita superioara : ");
            string b = Console.ReadLine();
            int b1 = Convert.ToInt16(b);
            ServiceReference1.Service1Client serviciuClient = new Service1Client();
            string integrala=serviciuClient.GetData(a1, b1);
            Console.WriteLine("Valoarea integralei este :"+integrala);
            Console.ReadKey();

            // Go to http://aka.ms/dotnet-get-started-console to continue learning how to build a console app! 
        }
    }
}
