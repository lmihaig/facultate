#include<unistd.h>
int main(){
write(5,"B",1);
return 0;
}
/* Program auxiliar pentru "p27a"; nu se lanseaza direct */