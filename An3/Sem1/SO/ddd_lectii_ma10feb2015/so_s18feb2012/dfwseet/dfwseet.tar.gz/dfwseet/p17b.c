#include<stdio.h>
int main(){printf("B"); fflush(stdout); return 0;}
/* Program auxiliar pentru "p17a"; nu se lanseaza direct */