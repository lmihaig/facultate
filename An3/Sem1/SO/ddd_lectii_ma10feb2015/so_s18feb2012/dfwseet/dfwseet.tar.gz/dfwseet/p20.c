#include<stdlib.h>
void main(){ printf("%s\n",getenv("xx2")); }
/* Utilizare:
   Dam comanda:
     export xx2=20
   Lansam:
     p20
   Pe ecran se afisaza:
     20
*/