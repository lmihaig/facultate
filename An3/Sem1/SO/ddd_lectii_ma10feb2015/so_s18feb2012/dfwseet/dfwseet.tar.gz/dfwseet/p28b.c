#include<stdio.h>
int main(){printf("B"); fflush(stdout); return 0;}
/* Program auxiliar pentru "p28a"; nu se lanseaza direct */