#include<stdio.h>
#include"functii.h"
int main(){
  double a, b;
  do{
    printf("a = "); scanf("%lf",&a); 
    if((b=factorial(a))==-1)afisaza_eroare(a);
      else printf("%d factorial este %d\n",(int)a,(int)b);
    if((b=radical(a))==-1)afisaza_eroare(a);
      else printf("radical din %lf este %lf\n",a,b);
  }while(a!=0);
  return 0;
}
