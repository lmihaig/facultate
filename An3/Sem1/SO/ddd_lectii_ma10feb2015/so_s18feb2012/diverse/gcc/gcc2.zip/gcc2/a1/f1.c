#include<stdio.h>
int a,b,c;
int main(){
 printf("a = "); scanf("%d",&a);
 printf("b = "); scanf("%d",&b);
 c=(a*a+b*b)*2;
 printf("rezultat = %d\n",c);
 return 0;
}

