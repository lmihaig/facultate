#include<math.h>
#include"functii.h"
 #include"erori.h"
double factorial(double x){
 int i,f;
 if(x<0){numar_eroare=1; return -1;}
 if(x!=(int)x){numar_eroare=2; return -1;}
 f=1; for(i=1;i<=x;++i)f*=i;
 numar_eroare=0;
 return f;
}
double radical(double x){
 if(x<0){numar_eroare=1; return -1;}
 numar_eroare=0;
 return sqrt(x);
}
