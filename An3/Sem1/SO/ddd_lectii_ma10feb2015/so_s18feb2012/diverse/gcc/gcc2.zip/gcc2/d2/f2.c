#include<stdio.h>
#include<ctype.h>
void test(char *);
void mare(char *q){
  char k;
  k=*q;
  printf("%c mare\n",k);
  test(q+1);
}
void mica(char *r){
  char l;
  l=*r;
  printf("%c mica\n",l);
  test(r+1);
}
void test(char *p){
  char c;
  c=*p;
  if(!c) return;
  if(isupper(c)) mare(p);
  else if(islower(c)) mica(p);
}
int main(){
  char s[]="abAcBCDe";
  test(s);
  return 0;
}

