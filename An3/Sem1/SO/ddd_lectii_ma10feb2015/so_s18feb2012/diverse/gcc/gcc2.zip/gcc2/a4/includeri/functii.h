double factorial(double);
double radical(double);
