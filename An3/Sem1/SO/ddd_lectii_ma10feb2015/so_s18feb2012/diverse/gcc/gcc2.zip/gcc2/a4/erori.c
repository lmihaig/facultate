#include<stdio.h>
#include"erori.h"
int numar_eroare;
void afisaza_eroare(double n){
  printf("%lf: ",n);
  switch(numar_eroare){
    case 0: printf("corect\n"); break;
    case 1: printf("negativ\n"); break;
    case 2: printf("nu este intreg\n"); break;
    default: printf("incorect din motive necunoscute\n");
  }
}
