int sumapatrate(int);

