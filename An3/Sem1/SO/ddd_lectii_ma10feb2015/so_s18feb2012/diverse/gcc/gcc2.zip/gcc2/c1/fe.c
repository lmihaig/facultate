#include<stdio.h>
#include"fe.h"
void e(){printf("e ");}

