extern int operand1, operand2;

