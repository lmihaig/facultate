#include<stdio.h>
void fct(int x){
  printf("fct = %d",x);
}
int main(){
  int a,b,c,d;
  a=0;
  do{
    ++a;
    printf("a = %d\n",a);
  }while(a<10);
  b=0; c=0; d=0;
  do{
    b+=1;   printf("b = %d\n",b);
    c+=10;  printf("c = %d\n",c);
    d+=100; printf("d = %d\n",d);
  }while(b<10);
  fct(1);
  return 0;
}

