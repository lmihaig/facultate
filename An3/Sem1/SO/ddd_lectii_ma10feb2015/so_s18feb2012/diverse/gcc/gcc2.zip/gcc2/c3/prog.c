#include<stdio.h>
#include"prog.h"
#include"functii.h"
int operand1, operand2;
int main(){
  printf("Primul operand = "); scanf("%d",&operand1);
  printf("Al 2-lea operand = "); scanf("%d",&operand2);
  afisaza_suma();
  afisaza_produs();
  return 0;
}

