void afisare_suma();
void afisare_produs();

