#include"dublu.h"
int dublu(int n){
 return 2*n;
}

