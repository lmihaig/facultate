#include<stdio.h>
int fct(int x){
  int y;
  y=x+1; y=x+2; y=x+3;
  y=x+4;
  y=x+5;
  return y;
}
int main(){
  int i;
  i=10; printf("%d\n",i);
  i=20; printf("%d\n",i);
  i=30; printf("%d\n",i);
  i=40; printf("%d\n",i);
  i=50; printf("%d\n",i);
  while(1){
    i=1; i=2; i=fct(100); i=3; i=4;
    i=10; i=20; i=fct(1000); i=30; i=40;
  }
  i=100; i=200; printf("%d\n",i); i=300; i=400;
  i=1000; i=2000; printf("%d\n",i); i=3000; i=4000;
  return 0;
}

