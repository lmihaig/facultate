#include<stdio.h>
#include "sumapatrate.h"
#include "dublu.h"
int a,b,c;
int main(){
 printf("a = "); scanf("%d",&a);
 printf("b = "); scanf("%d",&b);
 c=dublu(sumapatrate(a)+sumapatrate(b));
 printf("rezultat = %d\n",c);
 return 0;
}
