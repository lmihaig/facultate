extern int numar_eroare;
void afisaza_eroare(double);
