#include<stdio.h>
#include"fa.h"
#include"fb.h"
#include"fd.h"
void d(){a(); b(); printf("d ");}

