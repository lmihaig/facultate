#include"patrat.h"
int patrat(int n){
 return n*n;
}

