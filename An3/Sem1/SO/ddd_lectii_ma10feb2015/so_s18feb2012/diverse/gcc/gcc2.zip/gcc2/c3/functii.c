#include<stdio.h>
#include"prog.h"
#include"functii.h"
void afisaza_suma(){printf("Suma este: %d\n",operand1+operand2);}
void afisaza_produs(){printf("Produsul este: %d\n",operand1*operand2);}

