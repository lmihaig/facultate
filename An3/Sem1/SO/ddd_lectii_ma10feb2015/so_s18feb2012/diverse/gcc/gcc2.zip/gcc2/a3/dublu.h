int dublu(int);

