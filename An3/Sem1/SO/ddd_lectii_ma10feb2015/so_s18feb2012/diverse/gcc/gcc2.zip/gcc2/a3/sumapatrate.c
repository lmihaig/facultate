#include"patrat.h"
#include"sumapatrate.h"
int sumapatrate(int n){
 int i,s;
 s=0; for(i=1;i<=n;++i) s+=patrat(i);
 return s;
}

