#include<stdio.h>
#include"fd.h"
#include"fe.h"
int main(){
  d(); printf("\n");
  e(); printf("\n");
  return 0;
}

