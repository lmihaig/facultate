#define VALOARE 10
int x;
int main(){
 x=VALOARE;
 return 0;
}

