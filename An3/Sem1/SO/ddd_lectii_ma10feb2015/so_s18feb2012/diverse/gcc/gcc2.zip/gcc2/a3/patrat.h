int patrat(int);

