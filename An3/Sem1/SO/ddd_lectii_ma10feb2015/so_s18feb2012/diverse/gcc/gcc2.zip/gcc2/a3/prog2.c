#include<stdio.h>
#include "sumapatrate.h"
int a,c;
int main(){
 printf("a = "); scanf("%d",&a);
 c=sumapatrate(a);
 printf("rezultat = %d\n",c);
 return 0;
}
